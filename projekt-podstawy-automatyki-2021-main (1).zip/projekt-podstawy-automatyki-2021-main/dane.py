
base_list = ['NaOH', 'KOH', 'LiOH', 'RbOH', 'Be(OH)2', 'Ca(OH)2']
acid_list = ['HCl', 'H2SO4', 'HNO3', 'H3PO4', 'HBR', 'H2CO3']

mole_amount = {
    "NaOH": 1,
    "KOH": 1,
    "LiOH": 1,
    "RbOH": 1,
    "Be(OH)2": 2,
    "Ca(OH)2": 2,
    "HCl": 1,
    "H2SO4": 2,
    "HNO3": 1,
    "H3PO4": 3,
    "HBR": 1,
    "H2CO3": 2,
}


def mole_ratio(substrate1, substrate2):
    return [mole_amount[substrate1], mole_amount[substrate2]]
