import pandas as pd
import numpy as np
import streamlit as st
import math
import dane as d

# dobór nastaw PID metodami Zieglera-Nicholsa
# celem jest osiągnięcie odpowiedzi aperiodycznej (κ = 0%) przy minimalnym czasie ustalania (tr › min).
# dla regulatora PID kp = 1.2/a, Ti = 2*T0, Td = 0.5*T0

# uruchamiamy streamlit run automatyka.py

time_sim = 4 * 3600
T_p = 0.5
T_i = 1
T_d = 1
checks_overall = int(time_sim / T_p)

k_p = 0.000002

min_vol = 0.0
max_vol = 2000.0
min_input_per_second = 0.0
max_input_per_second = 2.0


def ph_linear(ph_value: float):
    if ph_value < 7.0:
        return 10 ** (7 - ph_value)
    if ph_value > 7.0:
        return -(10 ** (ph_value - 7))
    return 0


def calculate_ph(base_v, base_c, acid_v, acid_c, ratio):
    total_volume = base_v + acid_v
    base_mole = base_c * base_v
    acid_mole = acid_c * acid_v

    # """solution is neutral, pH is 7"""
    if ratio[0] * acid_mole == ratio[1] * base_mole:
        return 7

    # """solution is acidic, pH is lower than 7"""
    if ratio[0] * acid_mole > ratio[1] * base_mole:
        moles = (base_mole * ratio[1]) / ratio[0]
        h_ion_conc = (acid_mole - moles) / total_volume
        ph = -(math.log10(h_ion_conc))

        return max(ph, 0)

    # """solution is basic, ph is higher than 7"""
    moles = (acid_mole * ratio[0]) / ratio[1]
    oh_ion_conc = (base_mole - moles) / total_volume
    ph = 14 + math.log10(oh_ion_conc)
    return min(ph, 14)


def simulate(vol1, conc1, conc2, ratio, target_ph, sub1):
    lista_ph = [
        calculate_ph(0, 1, vol1, conc1, ratio) if sub1 in d.acid_list else calculate_ph(vol1, conc1, 0, 1, ratio)]
    lista_obj = [vol1]
    lista_ph_lin = [ph_linear(lista_ph[-1])]
    target_ph_lin = ph_linear(target_ph)
    lista_uchyb = [target_ph_lin - lista_ph_lin[-1]]
    lista_czas = [0.0]
    max_volume = [max_vol]
    min_volume = [min_vol]

    target_ph_lista = [target_ph]
    target_ph_lin_lista = [target_ph_lin]

    if sub1 in d.acid_list:
        for i in range(1, checks_overall):
            lista_uchyb.append(target_ph_lin - lista_ph_lin[-1])
            u_pomiar = k_p * -(lista_uchyb[-1])
            u = min(max_input_per_second, max(min_input_per_second, u_pomiar))*T_p
            h_pomiar = 1 * u + lista_obj[-1]
            lista_obj.append(min(max_vol, max(min_vol, h_pomiar)))
            lista_ph.append(calculate_ph(lista_obj[-1] - vol1, conc2, vol1, conc1, ratio))
            lista_ph_lin.append(ph_linear(lista_ph[-1]))
            lista_czas.append(i * T_p)
    if sub1 in d.base_list:
        for i in range(1, checks_overall):
            lista_uchyb.append(target_ph_lin - lista_ph_lin[-1])
            u_pomiar = k_p * (lista_uchyb[-1])
            #+ (T_p / T_i) * sum(lista_uchyb) + (T_d / T_p) * (lista_uchyb[-1] - lista_uchyb[-2])
            u = min(max_input_per_second * T_p, max(min_input_per_second * T_p, u_pomiar))
            h_pomiar = 1 * u + lista_obj[-1]
            lista_obj.append(min(max_vol, max(min_vol, h_pomiar)))
            lista_ph.append(calculate_ph(vol1, conc1, lista_obj[-1] - vol1, conc2, ratio))
            lista_ph_lin.append(ph_linear(lista_ph[-1]))
            lista_czas.append(i * T_p)

    for i in range(checks_overall-1):
        lista_ph[i] = round(lista_ph[i], 2)
        lista_ph_lin[i] = round(lista_ph_lin[i], 0)
        lista_obj[i] = round(lista_obj[i], 1)
        target_ph_lista.append(target_ph)
        target_ph_lin_lista.append(target_ph_lin)
        max_volume.append(max_vol)
        min_volume.append(min_vol)

    return pd.DataFrame({"Target PH": target_ph_lista, "pH": lista_ph}, index=lista_czas), \
            pd.DataFrame({"Target": target_ph_lin_lista, "H ions per mol": lista_ph_lin}, index=lista_czas), \
            pd.DataFrame({"Volume(cm^3)  ": lista_obj, "Minimum volume(cm^3)": min_volume, "Maximum volume(cm^3)": max_volume}, index=lista_czas)


def main():
    st.title('Solutions mixing')

    col1, col2 = st.columns(2)
    with col1:
        substance1 = st.selectbox('First substrate:', d.base_list + d.acid_list)
        substance1_volume = st.slider("Enter volume[cm3]:", 10.0, 1000.0, 100.0, format='%.2f')
        substance1_conc = st.number_input('Enter first concentration[mol/cm3]:', 0.01, step=0.01, format='%.2f')
    with col2:
        substance2 = st.selectbox('Second substrate:', d.acid_list if substance1 in d.base_list else d.base_list)
        substance2_conc = st.number_input('Enter second concentration[mol/cm3]:', 0.01, step=0.01, format='%.2f')

    # slider for ph from 0 - 14
    target_ph = st.slider('what solution pH do you want to get?', 0.0, 14.0, 7.0, step=0.1)

    # st.write("You have to pour in:",
    #          calc_volume(target_ph, d.mole_ratio(substance1, substance2),
    #                      substance1_conc, substance1_volume,
    #                      substance2_conc, substance1),
    #          "ml of base" if substance1 in d.acid_list else "ml of acid", substance2)

    chart1, chart2, chart3 = simulate(substance1_volume, substance1_conc, substance2_conc,
                                      d.mole_ratio(substance1, substance2), target_ph,
                                      substance1)
    st.write("pH of solution to time")
    st.line_chart(chart1)
    st.write("H ions per mol to time")
    st.line_chart(chart2)
    st.write("Volume to time")
    st.line_chart(chart3)


if __name__ == "__main__":
    main()
